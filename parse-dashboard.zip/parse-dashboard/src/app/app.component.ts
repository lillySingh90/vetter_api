import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient } from "@angular/common/http";

interface DataResponse {
  userId: string;
  id: string;
  title: string;
  body: string;
}

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent implements OnInit {
  title = "app";
  responses$: Observable<DataResponse[]>;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // adding the lifecycle hook ngOnInit
    this.responses$ = this.http.get<DataResponse[]>(
      "http://jsonplaceholder.typicode.com/posts"
    );
  }
}
